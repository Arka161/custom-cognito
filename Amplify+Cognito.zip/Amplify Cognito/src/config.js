export default {
    // apiGateway: {
    //     REGION  : 'REGION',
    //     URL     : 'API_GW_INVOKE_URL_HERE'
    // },
    cognito: {
        REGION              : 'REGION_HERE',
        USER_POOL_ID        : 'USER_POOL_ID_HERE',
        APP_CLIENT_ID       : 'APP_CLIENT_ID_HERE',             // GO for the app_clientWeb
        IDENTITY_POOL_ID    : 'IDENTITY_POOL_ID_HERE'
    }
}
